﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinSnake
{
    class Comida
    {
        private int x, y;
        private int longt;
        private int ancho, alto;
        Random r;
        public Comida(int ancho, int alto)
        {
            this.ancho = ancho;
            this.alto = alto;
            r = new Random();
            generarComida();
            longt = 10;
        }
        public void Dibujar(Graphics g)
        {
            g.FillRectangle(Brushes.Black, x, y, longt, longt);
        }
        public void generarComida()
        {
            x = r.Next(0, (ancho - longt) / 10) * 10;
            y = r.Next(0, (alto - longt) / 10) * 10;
        }
        public int getX()
        {
            return this.x;
        }
        public int getY()
        {
            return this.y;
        }
    }
}
