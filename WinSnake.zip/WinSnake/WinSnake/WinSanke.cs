﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinSnake
{
    public partial class WinSanke : Form
    {
        Comida c;
        Serpiente s;
        
        private int dirx = 0, diry = 0;
        private int longt = 10;
        private int puntaje=0;
        public WinSanke()
        {
            InitializeComponent();
            c = new Comida(cancha.Width, cancha.Height);
            s = new Serpiente(cancha.Width,cancha.Height);
        }
        private void Salir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void cancha_Click(object sender, EventArgs e)
        { }
        private void cancha_Paint(object sender, PaintEventArgs e)
        {
            c.Dibujar(e.Graphics);
            s.Dibujar(e.Graphics);
        }
        private void timer_Tick(object sender, EventArgs e)
        {
            Mover();
            cancha.Invalidate();
          if (s.Chocar(c))
          {
                puntaje+=10;
                label1.Text = puntaje.ToString();
                c.generarComida();
                s.cola();
          }
        }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            bool ejex = true, ejey = true;
            if (ejex)
            {
                if (keyData == Keys.Up)
                {
                    diry = -longt;
                    dirx = 0;
                    ejex = false;
                    ejey = true;
                }
                if (keyData == Keys.Down)
                {
                    diry = longt;
                    dirx = 0;
                    ejex = false;
                    ejey = true;
                }
            }
            if (ejey)
            {
                if (keyData == Keys.Right)
                {
                    dirx = longt;
                    diry = 0;
                    ejey = false;
                    ejex = true;
                }
                if (keyData == Keys.Left)
                {
                    dirx = -longt;
                    diry = 0;
                    ejey = false;
                    ejex = true;
                }
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }

        public void Mover()
        {
            s.setX(s.getX() + dirx);
            s.setY(s.getY() + diry);
            if ((s.getX()+dirx)>=cancha.Width)
            {
                s.setX(s.getX() - cancha.Width);
                s.setY(s.getY());
            }
            if ((s.getX()+dirx)<-longt)
            {
                s.setX(s.getX() + cancha.Width);
            }
            if((s.getY() + diry) >= cancha.Height)
            {
                s.setY(s.getY() - cancha.Height);
                s.setX(s.getX());
            }
            if(s.getY()+diry<-longt)
            {
                s.setY(s.getY() + cancha.Height);
                s.setX(s.getX());
            }

        }
        
    }
}
