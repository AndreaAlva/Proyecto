﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinSnake
{
    class Serpiente
    {
        private int x, y;
        private Brush color;
        private int longt;
        Serpiente s;
        public Serpiente(int ancho, int alto)
        {
            x = ancho / 78;
            y = alto / 10;
            color = Brushes.Red;
            longt = 10;
            s = null;
        }
        public void Dibujar(Graphics g)
        {  
            if(s!=null)
            {
              s.Dibujar(g);
            }
            g.FillRectangle(color, x, y, longt, longt);
           
        }
        public bool Chocar(Comida c)
        {
            int distx = Math.Abs(this.x - c.getX());
            int disty = Math.Abs(this.y - c.getY());
            if (distx >= 0 && distx < longt && disty >= 0 && disty < longt)
            {
                return true;
            }
            else
                return false;
        }
        public void setX(int x)
        {
            if(s!=null)
            {
              s.setX(getX());
            }
            this.x = x;
        }
        public void setY(int y)
        {
            if (s != null)
            { 
                s.setY(getY()); 
            }
            this.y = y;
        }
        public int getX()
        {
            return this.x;
        }
        public int getY()
        {
            return this.y;
        }  
        public void cola()
        {
           if(s==null)
           {
              s = new Serpiente(this.x,this.y);
              
           }
           else 
            s.cola();
        }
      
    }
}

